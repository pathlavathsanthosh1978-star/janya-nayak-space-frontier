"""
Janya Nayak: Space Frontier
----------------------------
A Flask web app covering space exploration and space-mission R&D:
a live mission dashboard, an ISRO mission archive, a solar-system
explorer, and a research hub on the technology behind spaceflight.

Run:
    pip install -r requirements.txt
    python app.py
Then open http://127.0.0.1:5000
"""

from datetime import datetime, timezone

import requests
from flask import Flask, render_template

from data.sample_data import (
    FALLBACK_LAUNCHES,
    ISRO_MISSIONS,
    PLANETS,
    RESEARCH_ARTICLES,
)

app = Flask(__name__)

SPACEX_API = "https://api.spacexdata.com/v4"
NASA_APOD_API = "https://api.nasa.gov/planetary/apod"
NASA_DEMO_KEY = "DEMO_KEY"  # Swap in a free key from api.nasa.gov for
                              # higher rate limits (DEMO_KEY is heavily
                              # throttled).
REQUEST_TIMEOUT = 6  # seconds — fail fast rather than hang the page


def fetch_json(url, params=None):
    """GET a URL and return parsed JSON, or None on any failure."""
    try:
        response = requests.get(url, params=params, timeout=REQUEST_TIMEOUT)
        response.raise_for_status()
        return response.json()
    except (requests.RequestException, ValueError):
        return None


def get_upcoming_launches(limit=5):
    data = fetch_json(
        f"{SPACEX_API}/launches/upcoming",
    )
    if not data:
        return FALLBACK_LAUNCHES["upcoming"]

    launches = []
    for item in sorted(data, key=lambda x: x.get("date_utc") or "")[:limit]:
        launches.append(
            {
                "name": item.get("name", "Unnamed mission"),
                "date_utc": _format_date(item.get("date_utc")),
                "rocket": "SpaceX",
                "details": item.get("details")
                or "No mission details published yet.",
            }
        )
    return launches or FALLBACK_LAUNCHES["upcoming"]


def get_past_launches(limit=6):
    data = fetch_json(f"{SPACEX_API}/launches/past")
    if not data:
        return FALLBACK_LAUNCHES["past"]

    launches = []
    for item in sorted(
        data, key=lambda x: x.get("date_utc") or "", reverse=True
    )[:limit]:
        launches.append(
            {
                "name": item.get("name", "Unnamed mission"),
                "date_utc": _format_date(item.get("date_utc")),
                "success": item.get("success"),
                "details": item.get("details")
                or "No mission details published.",
            }
        )
    return launches


def get_apod():
    """NASA Astronomy Picture of the Day, for the dashboard hero."""
    data = fetch_json(NASA_APOD_API, params={"api_key": NASA_DEMO_KEY})
    if not data or data.get("media_type") != "image":
        return None
    return {
        "title": data.get("title"),
        "explanation": data.get("explanation"),
        "url": data.get("url"),
        "date": data.get("date"),
    }


def _format_date(date_utc):
    if not date_utc:
        return "Date TBD"
    try:
        dt = datetime.fromisoformat(date_utc.replace("Z", "+00:00"))
        return dt.strftime("%d %b %Y, %H:%M UTC")
    except ValueError:
        return date_utc


@app.context_processor
def inject_globals():
    return {"current_year": datetime.now(timezone.utc).year}


@app.route("/")
def home():
    upcoming = get_upcoming_launches(limit=3)
    apod = get_apod()
    stats = {
        "isro_missions": len(ISRO_MISSIONS),
        "planets_catalogued": len(PLANETS),
        "research_topics": len(RESEARCH_ARTICLES),
    }
    return render_template(
        "index.html",
        upcoming=upcoming,
        apod=apod,
        stats=stats,
        next_launch=upcoming[0] if upcoming else None,
    )


@app.route("/missions")
def missions():
    upcoming = get_upcoming_launches(limit=8)
    past = get_past_launches(limit=8)
    return render_template(
        "missions.html",
        upcoming=upcoming,
        past=past,
        isro_missions=ISRO_MISSIONS,
    )


@app.route("/explore")
def explore():
    return render_template("explore.html", planets=PLANETS)


@app.route("/research")
def research():
    categories = sorted({a["category"] for a in RESEARCH_ARTICLES})
    return render_template(
        "research.html",
        articles=RESEARCH_ARTICLES,
        categories=categories,
    )


if __name__ == "__main__":
    app.run(debug=True)
