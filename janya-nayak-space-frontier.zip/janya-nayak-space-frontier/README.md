# Janya Nayak: Space Frontier

A Flask web app about space exploration and space-mission R&D: a live
mission dashboard, an ISRO mission archive, a solar-system explorer, and
a research hub covering the engineering problems behind spaceflight.

## Setup

```bash
pip install -r requirements.txt
python app.py
```

Then open **http://127.0.0.1:5000** in your browser.

## Pages

| Route        | What it shows |
|--------------|----------------|
| `/`          | Dashboard — NASA picture of the day, next launch, quick stats |
| `/missions`  | Live upcoming/past launches (SpaceX public API) + ISRO mission archive |
| `/explore`   | Solar system reference cards (planets) |
| `/research`  | R&D briefings on propulsion, life support, ISRU, etc., filterable by category |

## Live data sources

- **SpaceX Launches API** (`api.spacexdata.com`) — no API key needed.
- **NASA APOD API** (`api.nasa.gov/planetary/apod`) — uses the public
  `DEMO_KEY`, which is rate-limited. Get a free key at
  https://api.nasa.gov and set it in `app.py` (`NASA_DEMO_KEY`) for
  higher limits.

If either API is unreachable (no internet, rate limit, etc.) the app
falls back to placeholder data automatically — it will never crash or
show a blank page.

ISRO mission data, planet facts, and research briefings are curated and
stored in `data/sample_data.py`, since there's no free live API for
these. Edit that file to add or update content.

## Project structure

```
app.py                   Flask routes + API calls
data/sample_data.py       Curated ISRO / planet / research content + fallbacks
templates/                Jinja2 HTML templates
static/css/style.css      Design system (mission-control theme)
static/js/main.js         Mobile nav + filter-chip interactions
```

## Extending it

- Swap in a real ISRO/NASA launch-schedule API if one becomes available.
- Add a detail page per mission (`/missions/<id>`) using the `id` field
  already present in the ISRO dataset.
- Add a database (SQLite via SQLAlchemy) if you want user accounts,
  saved missions, or comments.
