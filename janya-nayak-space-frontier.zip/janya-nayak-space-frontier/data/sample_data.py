"""
Curated reference data for Janya Nayak: Space Frontier.

This data is used as (a) the permanent content for missions that don't have
a public live-data API (e.g. ISRO), and (b) a fallback whenever a live API
call fails, so the app never shows a broken page.
"""

# ---------------------------------------------------------------------------
# Indian Space Research Organisation (ISRO) missions — curated, static.
# ---------------------------------------------------------------------------
ISRO_MISSIONS = [
    {
        "id": "chandrayaan-3",
        "name": "Chandrayaan-3",
        "status": "Completed",
        "launch_date": "2023-07-14",
        "vehicle": "LVM3-M4",
        "objective": "Soft-land near the lunar south pole and operate the "
                      "Pragyan rover to study surface composition and "
                      "regolith properties.",
        "highlight": "First craft to touch down near the lunar south "
                      "pole; made India the fourth nation to achieve a "
                      "soft lunar landing.",
    },
    {
        "id": "aditya-l1",
        "name": "Aditya-L1",
        "status": "Operational",
        "launch_date": "2023-09-02",
        "vehicle": "PSLV-C57",
        "objective": "Study the Sun's corona, solar wind and magnetic "
                      "field from a halo orbit around the Sun-Earth L1 "
                      "Lagrange point.",
        "highlight": "India's first dedicated solar observatory mission, "
                      "carrying seven payloads including the VELC "
                      "coronagraph.",
    },
    {
        "id": "gaganyaan",
        "name": "Gaganyaan",
        "status": "In development",
        "launch_date": "TBD",
        "vehicle": "HLVM3 (human-rated)",
        "objective": "Send a three-member crew to low Earth orbit for "
                      "three days and return them safely, establishing "
                      "India's human spaceflight capability.",
        "highlight": "Uncrewed test flights and the crew escape system "
                      "are being validated ahead of the first crewed "
                      "flight.",
    },
    {
        "id": "mangalyaan",
        "name": "Mangalyaan (Mars Orbiter Mission)",
        "status": "Completed",
        "launch_date": "2013-11-05",
        "vehicle": "PSLV-C25",
        "objective": "Enter Mars orbit to study the planet's surface, "
                      "atmosphere and mineralogy, and demonstrate "
                      "interplanetary mission technology.",
        "highlight": "India became the first nation to reach Mars orbit "
                      "on its maiden attempt, and did so on a low budget.",
    },
    {
        "id": "shukrayaan",
        "name": "Shukrayaan-1",
        "status": "Planned",
        "launch_date": "TBD",
        "vehicle": "GSLV Mk II",
        "objective": "Orbit Venus to study its atmosphere, surface and "
                      "subsurface, focusing on active volcanism and "
                      "atmospheric chemistry.",
        "highlight": "Would be India's first dedicated Venus mission.",
    },
]

# ---------------------------------------------------------------------------
# Solar system bodies for the Explore section.
# ---------------------------------------------------------------------------
PLANETS = [
    {
        "id": "mercury",
        "name": "Mercury",
        "type": "Terrestrial planet",
        "distance_from_sun_million_km": 57.9,
        "day_length": "59 Earth days",
        "year_length": "88 Earth days",
        "fact": "Has the most extreme temperature swings in the solar "
                 "system, from about 430°C in sunlight to -180°C at night.",
    },
    {
        "id": "venus",
        "name": "Venus",
        "type": "Terrestrial planet",
        "distance_from_sun_million_km": 108.2,
        "day_length": "243 Earth days",
        "year_length": "225 Earth days",
        "fact": "Its thick CO2 atmosphere traps heat so effectively that "
                 "it is the hottest planet, hotter even than Mercury.",
    },
    {
        "id": "earth",
        "name": "Earth",
        "type": "Terrestrial planet",
        "distance_from_sun_million_km": 149.6,
        "day_length": "24 hours",
        "year_length": "365.25 days",
        "fact": "The only known world with liquid surface water and an "
                 "atmosphere able to sustain complex life.",
    },
    {
        "id": "mars",
        "name": "Mars",
        "type": "Terrestrial planet",
        "distance_from_sun_million_km": 227.9,
        "day_length": "24.6 hours",
        "year_length": "687 Earth days",
        "fact": "Home to Olympus Mons, the tallest volcano in the solar "
                 "system, and the primary target for current human "
                 "deep-space mission planning.",
    },
    {
        "id": "jupiter",
        "name": "Jupiter",
        "type": "Gas giant",
        "distance_from_sun_million_km": 778.5,
        "day_length": "9.9 hours",
        "year_length": "12 Earth years",
        "fact": "Its Great Red Spot is a storm wider than Earth that has "
                 "raged for at least 190 years.",
    },
    {
        "id": "saturn",
        "name": "Saturn",
        "type": "Gas giant",
        "distance_from_sun_million_km": 1434.0,
        "day_length": "10.7 hours",
        "year_length": "29.5 Earth years",
        "fact": "Its ring system is made almost entirely of ice particles "
                 "ranging from dust grains to boulders.",
    },
    {
        "id": "uranus",
        "name": "Uranus",
        "type": "Ice giant",
        "distance_from_sun_million_km": 2871.0,
        "day_length": "17.2 hours",
        "year_length": "84 Earth years",
        "fact": "Rotates on its side, with an axial tilt of about 98 "
                 "degrees, likely from an ancient collision.",
    },
    {
        "id": "neptune",
        "name": "Neptune",
        "type": "Ice giant",
        "distance_from_sun_million_km": 4495.0,
        "day_length": "16.1 hours",
        "year_length": "165 Earth years",
        "fact": "Has the strongest sustained winds in the solar system, "
                 "measured at over 2,000 km/h.",
    },
]

# ---------------------------------------------------------------------------
# Research & development notes for the Research Hub.
# ---------------------------------------------------------------------------
RESEARCH_ARTICLES = [
    {
        "id": "reusable-launch",
        "title": "Reusable Launch Vehicles",
        "category": "Propulsion",
        "summary": "Recovering and reflying boosters is the single "
                     "biggest lever on launch cost. Current work focuses "
                     "on faster refurbishment turnaround and reusable "
                     "upper stages, which remain the harder unsolved "
                     "problem.",
        "read_minutes": 4,
    },
    {
        "id": "electric-propulsion",
        "title": "Electric & Ion Propulsion",
        "category": "Propulsion",
        "summary": "Ion and Hall-effect thrusters trade thrust for very "
                     "high fuel efficiency, making them well suited to "
                     "station-keeping and deep-space cruise phases where "
                     "mission duration matters more than acceleration.",
        "read_minutes": 3,
    },
    {
        "id": "life-support",
        "title": "Closed-Loop Life Support",
        "category": "Human Spaceflight",
        "summary": "Long-duration missions depend on recycling air and "
                     "water on board rather than resupplying it. Current "
                     "ISS systems recover roughly 90 percent of water; "
                     "Mars-class missions will need that number higher "
                     "still.",
        "read_minutes": 5,
    },
    {
        "id": "isru",
        "title": "In-Situ Resource Utilization",
        "category": "Surface Operations",
        "summary": "Extracting oxygen, water and construction material "
                     "from lunar or Martian soil removes the need to "
                     "launch those resources from Earth, and is treated "
                     "as a prerequisite for any permanent surface base.",
        "read_minutes": 4,
    },
    {
        "id": "radiation-shielding",
        "title": "Radiation Shielding for Deep Space",
        "category": "Human Spaceflight",
        "summary": "Beyond low Earth orbit, crews lose the protection of "
                     "the magnetosphere. Research spans passive mass "
                     "shielding, water-wall habitats and early-stage "
                     "active magnetic shielding concepts.",
        "read_minutes": 4,
    },
    {
        "id": "autonomous-nav",
        "title": "Autonomous Navigation & Landing",
        "category": "Guidance & Control",
        "summary": "Missions like Chandrayaan-3's hazard-detection "
                     "landing system rely on onboard cameras and "
                     "processors to pick a safe touchdown site in real "
                     "time, without ground control in the loop.",
        "read_minutes": 3,
    },
    {
        "id": "megaconstellations",
        "title": "Small-Satellite Megaconstellations",
        "category": "Satellite Systems",
        "summary": "Mass-produced small satellites in low Earth orbit are "
                     "reshaping communications and Earth observation, "
                     "while raising new questions about orbital debris "
                     "and end-of-life disposal.",
        "read_minutes": 4,
    },
]

# ---------------------------------------------------------------------------
# Fallback launch data, used only if the live SpaceX API is unreachable.
# ---------------------------------------------------------------------------
FALLBACK_LAUNCHES = {
    "upcoming": [
        {
            "name": "Sample Mission — Live data unavailable",
            "date_utc": "TBD",
            "rocket": "—",
            "details": "Live launch data could not be reached right now. "
                        "Showing placeholder data — reload once you have "
                        "an internet connection.",
        }
    ],
    "past": [],
}
